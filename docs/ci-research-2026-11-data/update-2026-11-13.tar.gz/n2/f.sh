#!/bin/sh
gh api --paginate "repos/GemTalk/Jasper/actions/runs/$2/jobs?filter=all&per_page=100" --jq '.jobs[]|{run_id,id,name,run_attempt,conclusion,created_at,started_at,completed_at,steps:[.steps[]|{name,conclusion,started_at,completed_at}]}' > "$1/n2/jobs/$2.jsonl" 2>/dev/null
