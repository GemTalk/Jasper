#!/bin/sh
[ -s "$1/wk/$2.log" ] || gh api "repos/GemTalk/Jasper/actions/jobs/$3/logs" > "$1/wk/$2.log" 2>/dev/null
